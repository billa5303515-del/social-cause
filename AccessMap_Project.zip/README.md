# AccessMap – Smart Accessibility Navigator

A full-stack MVP inspired by the uploaded HSC presentation. It helps people discover accessibility information for places, view community/verified status, request route guidance where available, and submit reports about blocked ramps, lifts, entrances, and washrooms.

## Features
- Responsive React + TypeScript PWA-style interface
- Interactive OpenStreetMap powered by Leaflet
- Place discovery and category/accessibility filters
- Place detail cards with dated, sourced accessibility labels
- Report form with validation and API persistence
- Express + TypeScript REST API
- SQLite database (created and seeded automatically on first server start)
- Report moderation status and conservative trust labels
- Route preview via public OSRM demo service when available; clearly marked as a preview, not an accessibility/safety guarantee
- Health endpoint, basic error handling, API tests

## Requirements
- Node.js 20+ and npm
- Internet connection for OpenStreetMap tiles and optional public routing service

## Run locally
```bash
npm install
npm run dev
```
Open the Vite URL shown (usually http://localhost:5173). API runs at http://localhost:4000.

## Production build
```bash
npm run build
npm start
```
The API serves the built frontend from `client/dist` when present. Set `PORT` to change the API port.

## API
- `GET /api/health`
- `GET /api/places?search=&category=&accessibleOnly=`
- `GET /api/places/:id`
- `POST /api/reports` — create a community report
- `GET /api/reports` — report list for transparency/demo
- `PATCH /api/reports/:id/status` — demo moderation action (`pending`, `reviewed`, `rejected`)

## Data and trust limitations
Seed locations are demo records, not claims of real-world verified accessibility. The app deliberately distinguishes `Verified`, `Community reported`, and `Unknown`. For a real pilot, replace seed data with field-checked data and a defined verification workflow. Routes use a public demo endpoint and are not wheelchair-aware routing. Do not rely on this MVP as a safety guarantee. The OpenStreetMap public tile service has usage policies; use an appropriate tile provider for production traffic.

## Deploy
### Option A: Render (single service)
1. Push this folder to a GitHub repository.
2. Create a **Web Service** in Render and connect the repository.
3. Build command: `npm install && npm run build`
4. Start command: `npm start`
5. Set `NODE_VERSION` to `20` or newer.
6. Add a persistent disk mounted at `/opt/render/project/src/server/data` so SQLite data survives deploys; otherwise use a managed PostgreSQL database for a production deployment and migrate the repository accordingly.
7. Deploy. The server serves the frontend and API from one origin.

### Option B: Vercel + Render/Railway
The Vite client can be deployed to Vercel, but configure `VITE_API_BASE_URL` to the deployed API URL and configure CORS in the API. SQLite is not appropriate for ephemeral serverless storage; use managed PostgreSQL for this setup.

## GitHub upload
1. Create a new empty repository on GitHub.
2. Unzip this project and open a terminal in the project folder.
3. Run:
```bash
git init
git add .
git commit -m "Build AccessMap accessibility navigator MVP"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
Replace the example remote with your repository URL. Never commit secrets or real user-sensitive data.

## Remaining setup before a real launch
- Add the team's registered name/ID and pilot area.
- Replace demo seed data with validated place records.
- Define moderator authentication/authorization before enabling moderation publicly.
- Configure production database, backups, rate limiting, monitoring, privacy notice, consent, and retention policy.
- Integrate a wheelchair-aware routing provider and secure API keys if needed.
- Run screen-reader and real-device accessibility testing (WCAG 2.2 AA target).
