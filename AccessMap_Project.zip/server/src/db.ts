import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
const dir=path.resolve(process.cwd(),'data'); fs.mkdirSync(dir,{recursive:true});
export const db=new Database(path.join(dir,'accessmap.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS places(id TEXT PRIMARY KEY,name TEXT NOT NULL,category TEXT NOT NULL,address TEXT NOT NULL,lat REAL NOT NULL,lng REAL NOT NULL,entrance TEXT NOT NULL,ramp TEXT NOT NULL,lift TEXT NOT NULL,washroom TEXT NOT NULL,notes TEXT NOT NULL,source TEXT NOT NULL,status TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY,place_id TEXT,place_name TEXT NOT NULL,issue TEXT NOT NULL,details TEXT NOT NULL,reporter TEXT,created_at TEXT NOT NULL,status TEXT NOT NULL,FOREIGN KEY(place_id) REFERENCES places(id));`);
const count=(db.prepare('SELECT count(*) n FROM places').get() as {n:number}).n;
if(!count){const ins=db.prepare('INSERT INTO places VALUES(@id,@name,@category,@address,@lat,@lng,@entrance,@ramp,@lift,@washroom,@notes,@source,@status,@updated_at)'); const date=new Date().toISOString();
const rows=[
{id:'p1',name:'Marina Community Library',category:'Library',address:'Kamarajar Salai, Chennai',lat:13.0500,lng:80.2824,entrance:'Yes',ramp:'Yes',lift:'Unknown',washroom:'Unknown',notes:'Illustrative seed entry. Confirm on site before travel.',source:'Demo seed data',status:'Community reported',updated_at:date},
{id:'p2',name:'City Health Centre',category:'Healthcare',address:'Triplicane, Chennai',lat:13.0587,lng:80.2756,entrance:'Unknown',ramp:'Unknown',lift:'Yes',washroom:'Unknown',notes:'Illustrative seed entry. Details are not independently verified.',source:'Demo seed data',status:'Unknown',updated_at:date},
{id:'p3',name:'Neighbourhood Learning Hub',category:'Education',address:'Mylapore, Chennai',lat:13.0338,lng:80.2695,entrance:'Yes',ramp:'Unknown',lift:'No',washroom:'Unknown',notes:'Illustrative seed entry. Confirm with venue.',source:'Demo seed data',status:'Unknown',updated_at:date},
{id:'p4',name:'Civic Services Office',category:'Public service',address:'Chepauk, Chennai',lat:13.0644,lng:80.2800,entrance:'Unknown',ramp:'Yes',lift:'Unknown',washroom:'Yes',notes:'Illustrative seed entry. Data requires field validation.',source:'Demo seed data',status:'Community reported',updated_at:date}
]; for(const r of rows)ins.run(r);}
