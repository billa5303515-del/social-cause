import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import app from './index.js';
import type { AddressInfo } from 'node:net';

const server = app.listen(0);
await new Promise<void>((resolve) => server.once('listening', resolve));
const address = server.address() as AddressInfo;
const base = `http://127.0.0.1:${address.port}`;
after(() => new Promise<void>((resolve, reject) => server.close((err) => err ? reject(err) : resolve())));

test('API health endpoint responds', async () => {
  const r = await fetch(base + '/api/health');
  assert.equal(r.status, 200);
  const j = await r.json() as { status: string };
  assert.equal(j.status, 'ok');
});

test('places endpoint returns a list', async () => {
  const r = await fetch(base + '/api/places');
  assert.equal(r.status, 200);
  const j = await r.json() as unknown[];
  assert.ok(Array.isArray(j));
  assert.ok(j.length >= 1);
});

test('invalid reports are rejected', async () => {
  const r = await fetch(base + '/api/reports', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ placeName: 'x', issue: 'wrong', details: 'short' })
  });
  assert.equal(r.status, 400);
});
